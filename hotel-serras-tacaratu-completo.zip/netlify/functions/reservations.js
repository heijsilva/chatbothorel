const { MongoClient, ObjectId } = require('mongodb');

const uri = process.env.MONGODB_URI;
let cachedClient = null;

async function connectToDatabase() {
    if (cachedClient) {
        return cachedClient;
    }

    const client = new MongoClient(uri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    });

    await client.connect();
    cachedClient = client;
    return client;
}

exports.handler = async (event, context) => {
    // CORS headers
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Content-Type': 'application/json'
    };

    // Handle preflight requests
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ message: 'CORS preflight' })
        };
    }

    try {
        const client = await connectToDatabase();
        const db = client.db('hotel_serras_tacaratu');
        const collection = db.collection('reservations');

        switch (event.httpMethod) {
            case 'GET':
                try {
                    const name = event.queryStringParameters?.name;
                    const id = event.queryStringParameters?.id;

                    let query = {};

                    if (name) {
                        query.name = new RegExp(name, 'i');
                    }

                    if (id) {
                        query._id = new ObjectId(id);
                    }

                    const reservations = await collection.find(query).sort({ createdAt: -1 }).toArray();

                    return {
                        statusCode: 200,
                        headers,
                        body: JSON.stringify(reservations)
                    };
                } catch (error) {
                    console.error('GET Error:', error);
                    return {
                        statusCode: 500,
                        headers,
                        body: JSON.stringify({ 
                            error: 'Erro ao buscar reservas',
                            details: error.message 
                        })
                    };
                }

            case 'POST':
                try {
                    const reservationData = JSON.parse(event.body);

                    // Validação básica
                    if (!reservationData.name || !reservationData.checkin || !reservationData.checkout) {
                        return {
                            statusCode: 400,
                            headers,
                            body: JSON.stringify({ 
                                error: 'Dados obrigatórios não fornecidos',
                                required: ['name', 'checkin', 'checkout']
                            })
                        };
                    }

                    // Adicionar dados extras
                    const reservation = {
                        ...reservationData,
                        status: 'confirmed',
                        createdAt: new Date(),
                        updatedAt: new Date(),
                        hotel: 'Hotel Serras de Tacaratu'
                    };

                    const result = await collection.insertOne(reservation);

                    return {
                        statusCode: 200,
                        headers,
                        body: JSON.stringify({ 
                            id: result.insertedId,
                            success: true,
                            message: 'Reserva criada com sucesso!'
                        })
                    };
                } catch (error) {
                    console.error('POST Error:', error);
                    return {
                        statusCode: 500,
                        headers,
                        body: JSON.stringify({ 
                            error: 'Erro ao criar reserva',
                            details: error.message 
                        })
                    };
                }

            case 'PUT':
                try {
                    const updateData = JSON.parse(event.body);
                    const { id, ...updateFields } = updateData;

                    if (!id) {
                        return {
                            statusCode: 400,
                            headers,
                            body: JSON.stringify({ error: 'ID da reserva é obrigatório' })
                        };
                    }

                    updateFields.updatedAt = new Date();

                    const result = await collection.updateOne(
                        { _id: new ObjectId(id) },
                        { $set: updateFields }
                    );

                    if (result.matchedCount === 0) {
                        return {
                            statusCode: 404,
                            headers,
                            body: JSON.stringify({ error: 'Reserva não encontrada' })
                        };
                    }

                    return {
                        statusCode: 200,
                        headers,
                        body: JSON.stringify({ 
                            success: true,
                            message: 'Reserva atualizada com sucesso!'
                        })
                    };
                } catch (error) {
                    console.error('PUT Error:', error);
                    return {
                        statusCode: 500,
                        headers,
                        body: JSON.stringify({ 
                            error: 'Erro ao atualizar reserva',
                            details: error.message 
                        })
                    };
                }

            case 'DELETE':
                try {
                    const id = event.queryStringParameters?.id;

                    if (!id) {
                        return {
                            statusCode: 400,
                            headers,
                            body: JSON.stringify({ error: 'ID da reserva é obrigatório' })
                        };
                    }

                    const result = await collection.deleteOne({ _id: new ObjectId(id) });

                    if (result.deletedCount === 0) {
                        return {
                            statusCode: 404,
                            headers,
                            body: JSON.stringify({ error: 'Reserva não encontrada' })
                        };
                    }

                    return {
                        statusCode: 200,
                        headers,
                        body: JSON.stringify({ 
                            success: true,
                            message: 'Reserva cancelada com sucesso!'
                        })
                    };
                } catch (error) {
                    console.error('DELETE Error:', error);
                    return {
                        statusCode: 500,
                        headers,
                        body: JSON.stringify({ 
                            error: 'Erro ao cancelar reserva',
                            details: error.message 
                        })
                    };
                }

            default:
                return {
                    statusCode: 405,
                    headers,
                    body: JSON.stringify({ error: 'Método não permitido' })
                };
        }
    } catch (error) {
        console.error('Database connection error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ 
                error: 'Erro interno do servidor',
                details: error.message 
            })
        };
    }
};