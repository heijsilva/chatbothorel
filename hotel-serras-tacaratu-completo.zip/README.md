# 🌄 Hotel Serras de Tacaratu - Sistema de Reservas

## 🏨 Sobre o Projeto

Sistema completo de reservas para o Hotel Serras de Tacaratu, localizado no coração do sertão pernambucano. Desenvolvido com tecnologias modernas e design responsivo, oferece uma experiência única de navegação e reserva.

## ✨ Funcionalidades Principais

### 🤖 Chatbot Inteligente
- **Conversa Natural**: Interação humanizada e contextual
- **Menu Interativo**: 6 opções principais de navegação
- **Validação Inteligente**: Verificação de dados em tempo real
- **Armazenamento Local**: Histórico de conversas persistente
- **Responsivo**: Adaptável a todos os dispositivos

### 🛏️ Sistema de Reservas
- **CRUD Completo**: Criar, consultar, atualizar e cancelar reservas
- **Validação Avançada**: Verificação de datas, emails e telefones
- **Confirmação Automática**: Sistema de confirmação por email
- **Consulta Rápida**: Busca por nome ou ID da reserva

### 🎨 Design Premium
- **Interface Moderna**: Design clean e profissional
- **Animações Suaves**: Transições e efeitos visuais
- **Galeria Interativa**: Lightbox para visualização de imagens
- **Hero Slider**: Carrossel automático de imagens
- **Responsividade Total**: Perfeito em mobile, tablet e desktop

## 🚀 Tecnologias Utilizadas

### Frontend
- **HTML5**: Estrutura semântica moderna
- **CSS3**: Flexbox, Grid, Animations, Custom Properties
- **JavaScript ES6+**: Classes, Async/Await, Modules
- **Font Awesome**: Ícones profissionais
- **Google Fonts**: Tipografia premium (Playfair Display + Inter)

### Backend
- **Netlify Functions**: Serverless computing
- **MongoDB Atlas**: Banco de dados na nuvem
- **Node.js**: Runtime JavaScript

### Recursos Avançados
- **PWA Ready**: Preparado para Progressive Web App
- **SEO Otimizado**: Meta tags e estrutura semântica
- **Performance**: Lazy loading e otimizações
- **Acessibilidade**: ARIA labels e navegação por teclado

## 📱 Funcionalidades do Chatbot

### 🎯 Menu Principal
1. **🍽️ Restaurante**: Cardápio completo com pratos regionais
2. **🛏️ Acomodações**: Detalhes dos quartos e preços
3. **🏊‍♂️ Serviços**: Spa, piscina, trilhas e atividades
4. **📍 Localização**: Endereço e informações de acesso
5. **📅 Fazer Reserva**: Processo completo de reserva
6. **🔍 Consultar Reserva**: Busca e status de reservas

### 🔄 Fluxo de Reserva
1. **Data Check-in**: Validação de formato DD/MM/AAAA
2. **Data Check-out**: Verificação de datas válidas
3. **Tipo de Quarto**: 3 opções com preços
4. **Número de Hóspedes**: Validação de 1 a 6 pessoas
5. **Dados Pessoais**: Nome, telefone e email
6. **Confirmação**: Geração de ID único da reserva

## 🏗️ Estrutura do Projeto

```
hotel-serras-tacaratu/
├── index.html              # Página principal
├── css/
│   └── style.css          # Estilos principais
├── js/
│   └── script.js          # JavaScript principal
├── netlify/
│   └── functions/
│       └── reservations.js # API para MongoDB
├── package.json           # Dependências Node.js
├── netlify.toml          # Configurações Netlify
└── README.md             # Documentação
```

## 🚀 Como Hospedar no Netlify

### 1. Preparar MongoDB Atlas
```bash
1. Criar conta no MongoDB Atlas (gratuito)
2. Criar novo cluster
3. Configurar usuário e senha
4. Obter string de conexão
5. Criar database: hotel_serras_tacaratu
6. Criar collection: reservations
```

### 2. Deploy no Netlify
```bash
1. Fazer upload do ZIP no Netlify
2. Configurar variável de ambiente:
   - MONGODB_URI: sua_string_de_conexao_mongodb
3. Deploy automático será executado
```

### 3. Configurações Avançadas
- **Domínio Personalizado**: Configurar DNS
- **SSL**: Certificado automático
- **Analytics**: Monitoramento de tráfego
- **Forms**: Formulários de contato

## 🎨 Personalização

### Cores Principais
```css
--primary-color: #2c5530    /* Verde Sertão */
--secondary-color: #8b4513  /* Marrom Terra */
--accent-color: #d4af37     /* Dourado */
```

### Tipografia
- **Títulos**: Playfair Display (serif elegante)
- **Texto**: Inter (sans-serif moderna)

### Breakpoints Responsivos
- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

## 📊 Funcionalidades Avançadas

### 🔒 Segurança
- Validação de entrada de dados
- Sanitização de queries MongoDB
- Headers de segurança configurados
- CORS configurado adequadamente

### ⚡ Performance
- Lazy loading de imagens
- Minificação automática
- Cache de recursos estáticos
- Otimização de fontes

### 📱 Mobile First
- Design responsivo completo
- Touch gestures otimizados
- Menu mobile hamburger
- Chatbot adaptável

## 🛠️ Manutenção

### Logs e Monitoramento
- Netlify Analytics integrado
- Error tracking automático
- Performance monitoring

### Backup
- MongoDB Atlas backup automático
- Versionamento no Git
- Deploy rollback disponível

## 📞 Suporte

Para dúvidas técnicas ou suporte:
- **Email**: dev@serrastacaratu.com.br
- **Documentação**: Consulte este README
- **Issues**: Use o sistema de issues do repositório

## 🏆 Diferenciais

✅ **Chatbot Humanizado**: Conversa natural e inteligente  
✅ **Design Premium**: Interface profissional e moderna  
✅ **Totalmente Responsivo**: Perfeito em qualquer dispositivo  
✅ **Performance Otimizada**: Carregamento rápido  
✅ **SEO Friendly**: Otimizado para buscadores  
✅ **Fácil Manutenção**: Código limpo e documentado  
✅ **Escalável**: Preparado para crescimento  
✅ **Seguro**: Validações e proteções implementadas  

---

**Hotel Serras de Tacaratu** - Onde o luxo encontra a natureza do sertão pernambucano 🌄

*Desenvolvido com ❤️ para proporcionar experiências únicas*