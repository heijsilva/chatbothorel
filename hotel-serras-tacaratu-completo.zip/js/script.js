// Hotel Serras de Tacaratu - Sistema Avançado
class HotelSerrasTacaratu {
    constructor() {
        this.userName = '';
        this.userPhone = '';
        this.currentStep = 'greeting';
        this.reservationData = {};
        this.messages = JSON.parse(localStorage.getItem('hotelMessages') || '[]');
        this.isTyping = false;
        this.currentSlide = 0;
        this.galleryImages = [
            'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800',
            'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800',
            'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800',
            'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800'
        ];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.startHeroSlider();
        this.setupScrollEffects();
        this.hideLoadingScreen();
        this.loadChatMessages();

        // Iniciar conversa se for primeira vez
        if (this.messages.length === 0) {
            setTimeout(() => this.startConversation(), 1000);
        }
    }

    hideLoadingScreen() {
        setTimeout(() => {
            const loadingScreen = document.getElementById('loading-screen');
            if (loadingScreen) {
                loadingScreen.style.opacity = '0';
                setTimeout(() => {
                    loadingScreen.style.display = 'none';
                }, 500);
            }
        }, 2000);
    }

    setupEventListeners() {
        // Navigation toggle
        const navToggle = document.getElementById('nav-toggle');
        const navMenu = document.getElementById('nav-menu');

        if (navToggle) {
            navToggle.addEventListener('click', () => {
                navMenu.classList.toggle('active');
            });
        }

        // Smooth scrolling for navigation links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);
                this.scrollToSection(targetId);
                navMenu.classList.remove('active');
            });
        });

        // Chat input enter key
        const chatInput = document.getElementById('chat-input');
        if (chatInput) {
            chatInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }

        // Intersection Observer for animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in-up');
                }
            });
        }, observerOptions);

        // Observe elements for animation
        document.querySelectorAll('.room-card, .service-card, .gallery-item').forEach(el => {
            observer.observe(el);
        });
    }

    startHeroSlider() {
        const slides = document.querySelectorAll('.hero-slide');
        if (slides.length <= 1) return;

        setInterval(() => {
            slides[this.currentSlide].classList.remove('active');
            this.currentSlide = (this.currentSlide + 1) % slides.length;
            slides[this.currentSlide].classList.add('active');
        }, 5000);
    }

    setupScrollEffects() {
        const navbar = document.getElementById('navbar');

        window.addEventListener('scroll', () => {
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    }

    scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            const offsetTop = section.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    }

    // Chatbot Functions
    startConversation() {
        this.addMessage('🌄 Olá! Bem-vindo ao Hotel Serras de Tacaratu!', 'bot');
        setTimeout(() => {
            this.addMessage('Sou seu assistente virtual e estou aqui para ajudá-lo com tudo que precisar.', 'bot');
            setTimeout(() => {
                this.addMessage('Para começar, como você gostaria de ser chamado?', 'bot');
            }, 1500);
        }, 1000);
    }

    addMessage(text, sender, showOptions = false) {
        const chatMessages = document.getElementById('chat-messages');
        if (!chatMessages) return;

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;

        const avatar = document.createElement('div');
        avatar.className = 'message-avatar';
        avatar.innerHTML = sender === 'bot' ? '<i class="fas fa-robot"></i>' : '<i class="fas fa-user"></i>';

        const content = document.createElement('div');
        content.className = 'message-content';
        content.innerHTML = text;

        messageDiv.appendChild(avatar);
        messageDiv.appendChild(content);
        chatMessages.appendChild(messageDiv);

        if (showOptions && sender === 'bot') {
            setTimeout(() => this.showMenuOptions(), 1000);
        }

        this.messages.push({ text, sender, timestamp: new Date().toISOString() });
        this.saveMessages();
        this.scrollChatToBottom();
    }

    showTyping() {
        const typingDiv = document.getElementById('chat-typing');
        if (typingDiv) {
            typingDiv.style.display = 'flex';
            this.scrollChatToBottom();
        }
    }

    hideTyping() {
        const typingDiv = document.getElementById('chat-typing');
        if (typingDiv) {
            typingDiv.style.display = 'none';
        }
    }

    showMenuOptions() {
        const chatMessages = document.getElementById('chat-messages');
        const optionsDiv = document.createElement('div');
        optionsDiv.className = 'option-buttons';

        const options = [
            { text: '🍽️ Restaurante', value: 'restaurant', icon: 'utensils' },
            { text: '🛏️ Acomodações', value: 'rooms', icon: 'bed' },
            { text: '🏊‍♂️ Serviços', value: 'services', icon: 'swimming-pool' },
            { text: '📍 Localização', value: 'location', icon: 'map-marker-alt' },
            { text: '📅 Fazer Reserva', value: 'reservation', icon: 'calendar-check' },
            { text: '🔍 Consultar Reserva', value: 'check', icon: 'search' }
        ];

        options.forEach(option => {
            const btn = document.createElement('button');
            btn.className = 'option-btn';
            btn.innerHTML = `<i class="fas fa-${option.icon}"></i> ${option.text}`;
            btn.onclick = () => this.handleOptionClick(option.value);
            optionsDiv.appendChild(btn);
        });

        chatMessages.appendChild(optionsDiv);
        this.scrollChatToBottom();
    }

    handleOptionClick(option) {
        // Remove option buttons
        const optionButtons = document.querySelector('.option-buttons');
        if (optionButtons) optionButtons.remove();

        this.showTyping();

        setTimeout(() => {
            this.hideTyping();

            switch (option) {
                case 'restaurant':
                    this.showRestaurant();
                    break;
                case 'rooms':
                    this.showRooms();
                    break;
                case 'services':
                    this.showServices();
                    break;
                case 'location':
                    this.showLocation();
                    break;
                case 'reservation':
                    this.startReservation();
                    break;
                case 'check':
                    this.checkReservation();
                    break;
            }
        }, 1500);
    }

    showRestaurant() {
        const menu = `
            <strong>🍽️ Restaurante Serras Gourmet</strong><br><br>

            <strong>🥩 Pratos Principais:</strong><br>
            • Cordeiro Assado com Ervas do Sertão - R$ 65<br>
            • Peixe Pintado Grelhado - R$ 48<br>
            • Carne de Sol com Macaxeira - R$ 42<br>
            • Risotto de Queijo de Cabra - R$ 38<br><br>

            <strong>🍰 Sobremesas Regionais:</strong><br>
            • Doce de Leite com Castanha - R$ 18<br>
            • Pudim de Tapioca - R$ 15<br>
            • Cocada Queimada - R$ 12<br><br>

            <strong>🍹 Bebidas Especiais:</strong><br>
            • Caipirinha de Umbu - R$ 22<br>
            • Suco de Cajá - R$ 15<br><br>

            <em>Horário: 07h às 22h | Reservas: (87) 3826-1234</em><br><br>

            Como posso ajudá-lo mais? 😊
        `;
        this.addMessage(menu, 'bot', true);
    }

    showRooms() {
        const rooms = `
            <strong>🛏️ Nossas Acomodações</strong><br><br>

            <strong>🏨 Quarto Standard</strong> - R$ 180/noite<br>
            • Cama Queen Size confortável<br>
            • Vista para as serras<br>
            • Ar condicionado e Wi-Fi<br>
            • Frigobar e TV Smart<br><br>

            <strong>✨ Quarto Deluxe</strong> - R$ 280/noite<br>
            • Cama King Size premium<br>
            • Varanda privativa com rede<br>
            • Banheira de hidromassagem<br>
            • Vista panorâmica das serras<br><br>

            <strong>👑 Suíte Master</strong> - R$ 450/noite<br>
            • Sala de estar separada<br>
            • Jacuzzi privativa<br>
            • Terraço com vista 360°<br>
            • Serviço de mordomo<br><br>

            Todas incluem café da manhã regional! 🌅<br><br>

            Gostaria de fazer uma reserva? 📅
        `;
        this.addMessage(rooms, 'bot', true);
    }

    showServices() {
        const services = `
            <strong>🏊‍♂️ Nossos Serviços</strong><br><br>

            <strong>🏊‍♀️ Área Aquática:</strong><br>
            • Piscina infinity com vista das serras<br>
            • Deck molhado com espreguiçadeiras<br>
            • Bar aquático<br><br>

            <strong>💆‍♀️ Spa & Wellness:</strong><br>
            • Massagens relaxantes<br>
            • Tratamentos com argila do sertão<br>
            • Sauna seca<br><br>

            <strong>🥾 Atividades:</strong><br>
            • Trilhas ecológicas guiadas<br>
            • Passeios de quadriciclo<br>
            • Observação de estrelas<br>
            • Pesca esportiva<br><br>

            <strong>🎯 Outros Serviços:</strong><br>
            • Academia completa<br>
            • Salão de jogos<br>
            • Lavanderia<br>
            • Transfer do aeroporto<br><br>

            Que tal conhecer pessoalmente? 🌟
        `;
        this.addMessage(services, 'bot', true);
    }

    showLocation() {
        const location = `
            <strong>📍 Nossa Localização Privilegiada</strong><br><br>

            <strong>🏨 Hotel Serras de Tacaratu</strong><br>
            Serra do Tacaratu, s/n<br>
            Zona Rural - Tacaratu/PE<br>
            CEP: 56140-000<br><br>

            <strong>📞 Contatos:</strong><br>
            • Recepção: (87) 3826-1234<br>
            • WhatsApp: (87) 99999-8888<br>
            • Email: reservas@serrastacaratu.com.br<br><br>

            <strong>🚗 Como Chegar:</strong><br>
            • 15km do centro de Tacaratu<br>
            • 180km de Petrolina<br>
            • Transfer disponível<br><br>

            <strong>🌄 Diferenciais:</strong><br>
            • Vista panorâmica das serras<br>
            • Ar puro do sertão<br>
            • Céu estrelado incomparável<br>
            • Silêncio e tranquilidade<br><br>

            Venha se conectar com a natureza! 🍃
        `;
        this.addMessage(location, 'bot', true);
    }

    startReservation() {
        this.currentStep = 'reservation_checkin';
        this.addMessage('Perfeito! Vou ajudá-lo com sua reserva! 🎉', 'bot');
        setTimeout(() => {
            this.addMessage('Para começar, qual a data de check-in desejada? (DD/MM/AAAA)', 'bot');
        }, 1000);
    }

    checkReservation() {
        this.currentStep = 'check_reservation';
        this.addMessage('Para consultar sua reserva, preciso de algumas informações:', 'bot');
        setTimeout(() => {
            this.addMessage('Qual o nome usado na reserva?', 'bot');
        }, 1000);
    }

    async processReservation(data) {
        this.showTyping();

        try {
            const response = await fetch('/.netlify/functions/reservations', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...data,
                    hotel: 'Hotel Serras de Tacaratu',
                    createdAt: new Date().toISOString()
                })
            });

            this.hideTyping();

            if (response.ok) {
                const result = await response.json();
                this.addMessage(`✅ <strong>Reserva Confirmada!</strong><br><br>
                    <strong>ID da Reserva:</strong> ${result.id}<br>
                    <strong>Nome:</strong> ${data.name}<br>
                    <strong>Quarto:</strong> ${data.roomType}<br>
                    <strong>Check-in:</strong> ${data.checkin}<br>
                    <strong>Check-out:</strong> ${data.checkout}<br>
                    <strong>Hóspedes:</strong> ${data.guests}<br><br>

                    📧 Confirmação enviada para seu email!<br>
                    📱 Entraremos em contato via WhatsApp<br><br>

                    Obrigado por escolher o Hotel Serras de Tacaratu! 🌄`, 'bot', true);
            } else {
                this.addMessage('❌ Ops! Ocorreu um erro ao processar sua reserva. Por favor, tente novamente ou entre em contato conosco pelo telefone (87) 3826-1234.', 'bot', true);
            }
        } catch (error) {
            this.hideTyping();
            this.addMessage('❌ Erro de conexão. Verifique sua internet e tente novamente, ou ligue para (87) 3826-1234.', 'bot', true);
        }
    }

    async checkReservationById(name) {
        this.showTyping();

        try {
            const response = await fetch(`/.netlify/functions/reservations?name=${encodeURIComponent(name)}`);

            this.hideTyping();

            if (response.ok) {
                const reservations = await response.json();
                if (reservations.length > 0) {
                    let message = '<strong>🔍 Suas Reservas Encontradas:</strong><br><br>';
                    reservations.forEach((res, index) => {
                        message += `<strong>Reserva ${index + 1}:</strong><br>`;
                        message += `• ID: ${res._id}<br>`;
                        message += `• Quarto: ${res.roomType}<br>`;
                        message += `• Check-in: ${res.checkin}<br>`;
                        message += `• Check-out: ${res.checkout}<br>`;
                        message += `• Hóspedes: ${res.guests}<br>`;
                        message += `• Status: Confirmada ✅<br><br>`;
                    });
                    message += 'Precisa de mais alguma coisa? 😊';
                    this.addMessage(message, 'bot', true);
                } else {
                    this.addMessage('❌ Não encontrei nenhuma reserva com esse nome.<br><br>Verifique se digitou corretamente ou entre em contato conosco:<br>📞 (87) 3826-1234<br>📱 (87) 99999-8888', 'bot', true);
                }
            }
        } catch (error) {
            this.hideTyping();
            this.addMessage('❌ Erro ao consultar reserva. Tente novamente ou ligue para (87) 3826-1234.', 'bot', true);
        }
    }

    handleUserInput(input) {
        this.addMessage(input, 'user');
        this.showTyping();

        setTimeout(() => {
            this.hideTyping();
            this.processUserInput(input);
        }, 1000);
    }

    processUserInput(input) {
        switch (this.currentStep) {
            case 'greeting':
                this.userName = input;
                this.addMessage(`Prazer em conhecê-lo, ${this.userName}! 😊`, 'bot');
                setTimeout(() => {
                    this.addMessage(`Sou especialista em hospitalidade sertaneja e estou aqui para tornar sua experiência única!`, 'bot');
                    setTimeout(() => {
                        this.addMessage('Como posso ajudá-lo hoje?', 'bot', true);
                        this.currentStep = 'menu';
                    }, 1500);
                }, 1000);
                break;

            case 'reservation_checkin':
                if (this.isValidDate(input)) {
                    this.reservationData.checkin = input;
                    this.addMessage('Perfeito! E qual a data de check-out? (DD/MM/AAAA)', 'bot');
                    this.currentStep = 'reservation_checkout';
                } else {
                    this.addMessage('Por favor, digite uma data válida no formato DD/MM/AAAA (ex: 15/12/2024)', 'bot');
                }
                break;

            case 'reservation_checkout':
                if (this.isValidDate(input)) {
                    this.reservationData.checkout = input;
                    this.addMessage('Ótimo! Qual tipo de acomodação deseja?<br><br>1️⃣ Standard (R$ 180/noite)<br>2️⃣ Deluxe (R$ 280/noite)<br>3️⃣ Suíte Master (R$ 450/noite)', 'bot');
                    this.currentStep = 'reservation_room';
                } else {
                    this.addMessage('Por favor, digite uma data válida no formato DD/MM/AAAA (ex: 20/12/2024)', 'bot');
                }
                break;

            case 'reservation_room':
                const roomTypes = { 
                    '1': 'Standard (R$ 180/noite)', 
                    '2': 'Deluxe (R$ 280/noite)', 
                    '3': 'Suíte Master (R$ 450/noite)' 
                };
                if (roomTypes[input]) {
                    this.reservationData.roomType = roomTypes[input];
                    this.addMessage(`Excelente escolha! ${roomTypes[input]} 🏨`, 'bot');
                    setTimeout(() => {
                        this.addMessage('Quantos hóspedes?', 'bot');
                        this.currentStep = 'reservation_guests';
                    }, 1000);
                } else {
                    this.addMessage('Por favor, escolha uma opção válida:<br>1️⃣ Standard<br>2️⃣ Deluxe<br>3️⃣ Suíte Master', 'bot');
                }
                break;

            case 'reservation_guests':
                if (this.isValidNumber(input, 1, 6)) {
                    this.reservationData.guests = input;
                    this.addMessage('Perfeito! Agora preciso do nome completo para a reserva:', 'bot');
                    this.currentStep = 'reservation_name';
                } else {
                    this.addMessage('Por favor, digite um número válido de hóspedes (1 a 6)', 'bot');
                }
                break;

            case 'reservation_name':
                this.reservationData.name = input;
                this.addMessage('Ótimo! E qual seu telefone para contato?', 'bot');
                this.currentStep = 'reservation_phone';
                break;

            case 'reservation_phone':
                if (this.isValidPhone(input)) {
                    this.reservationData.phone = input;
                    this.addMessage('Por último, seu email:', 'bot');
                    this.currentStep = 'reservation_email';
                } else {
                    this.addMessage('Por favor, digite um telefone válido (ex: 87999998888 ou (87) 99999-8888)', 'bot');
                }
                break;

            case 'reservation_email':
                if (this.isValidEmail(input)) {
                    this.reservationData.email = input;
                    this.addMessage('Processando sua reserva... ⏳', 'bot');
                    this.processReservation(this.reservationData);
                    this.currentStep = 'menu';
                } else {
                    this.addMessage('Por favor, digite um email válido (ex: seuemail@gmail.com)', 'bot');
                }
                break;

            case 'check_reservation':
                this.checkReservationById(input);
                this.currentStep = 'menu';
                break;

            default:
                if (!this.userName) {
                    this.userName = input;
                    this.addMessage(`Olá ${this.userName}! Como posso ajudá-lo hoje?`, 'bot', true);
                    this.currentStep = 'menu';
                } else {
                    this.addMessage('Desculpe, não entendi. Por favor, escolha uma das opções do menu:', 'bot', true);
                }
        }
    }

    // Validation functions
    isValidDate(dateString) {
        const regex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
        return regex.test(dateString);
    }

    isValidNumber(num, min, max) {
        const number = parseInt(num);
        return !isNaN(number) && number >= min && number <= max;
    }

    isValidPhone(phone) {
        const regex = /^(\(?\d{2}\)?\s?)?\d{4,5}-?\d{4}$/;
        return regex.test(phone.replace(/\s/g, ''));
    }

    isValidEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }

    saveMessages() {
        localStorage.setItem('hotelMessages', JSON.stringify(this.messages));
    }

    loadChatMessages() {
        const chatMessages = document.getElementById('chat-messages');
        if (!chatMessages) return;

        this.messages.forEach(msg => {
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${msg.sender}`;

            const avatar = document.createElement('div');
            avatar.className = 'message-avatar';
            avatar.innerHTML = msg.sender === 'bot' ? '<i class="fas fa-robot"></i>' : '<i class="fas fa-user"></i>';

            const content = document.createElement('div');
            content.className = 'message-content';
            content.innerHTML = msg.text;

            messageDiv.appendChild(avatar);
            messageDiv.appendChild(content);
            chatMessages.appendChild(messageDiv);
        });

        this.scrollChatToBottom();
    }

    scrollChatToBottom() {
        const chatMessages = document.getElementById('chat-messages');
        if (chatMessages) {
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }
}

// Global Functions
let hotelSystem;

function openChatbot(action = null) {
    const chatContainer = document.getElementById('chatbot-container');
    const chatToggle = document.getElementById('chat-toggle');
    const notification = document.getElementById('chat-notification');

    if (chatContainer) {
        chatContainer.style.display = 'flex';
        chatToggle.style.display = 'none';

        if (notification) {
            notification.style.display = 'none';
        }

        if (!hotelSystem) {
            hotelSystem = new HotelSerrasTacaratu();
        }

        if (action === 'reservation') {
            setTimeout(() => {
                hotelSystem.handleOptionClick('reservation');
            }, 500);
        }
    }
}

function closeChatbot() {
    const chatContainer = document.getElementById('chatbot-container');
    const chatToggle = document.getElementById('chat-toggle');

    if (chatContainer) {
        chatContainer.style.display = 'none';
        chatToggle.style.display = 'flex';
    }
}

function minimizeChatbot() {
    const chatContainer = document.getElementById('chatbot-container');
    if (chatContainer) {
        chatContainer.classList.toggle('minimized');
    }
}

function maximizeChatbot() {
    const chatContainer = document.getElementById('chatbot-container');
    if (chatContainer) {
        chatContainer.classList.toggle('maximized');
    }
}

function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();

    if (message && hotelSystem) {
        hotelSystem.handleUserInput(message);
        input.value = '';
    }
}

function scrollToSection(sectionId) {
    if (hotelSystem) {
        hotelSystem.scrollToSection(sectionId);
    }
}

// Gallery Lightbox
let currentImageIndex = 0;
const galleryImages = [
    'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800',
    'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800',
    'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800',
    'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800'
];

function openLightbox(index) {
    currentImageIndex = index;
    const lightbox = document.getElementById('lightbox');
    const lightboxImage = document.getElementById('lightbox-image');

    if (lightbox && lightboxImage) {
        lightboxImage.src = galleryImages[index];
        lightbox.style.display = 'flex';
    }
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    if (lightbox) {
        lightbox.style.display = 'none';
    }
}

function prevImage() {
    currentImageIndex = (currentImageIndex - 1 + galleryImages.length) % galleryImages.length;
    document.getElementById('lightbox-image').src = galleryImages[currentImageIndex];
}

function nextImage() {
    currentImageIndex = (currentImageIndex + 1) % galleryImages.length;
    document.getElementById('lightbox-image').src = galleryImages[currentImageIndex];
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Show chat notification after 5 seconds
    setTimeout(() => {
        const notification = document.getElementById('chat-notification');
        if (notification) {
            notification.style.display = 'flex';
        }
    }, 5000);

    // Initialize hotel system
    hotelSystem = new HotelSerrasTacaratu();
});

// Close lightbox on escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeLightbox();
    }
});